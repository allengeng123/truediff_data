"""Utilities related to disk I/O."""

from tensorflow.keras.utils import HDF5Matrix
