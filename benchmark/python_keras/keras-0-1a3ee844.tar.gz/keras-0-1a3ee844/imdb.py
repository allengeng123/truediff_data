"""IMDB sentiment classification dataset."""

from tensorflow.keras.datasets.imdb import load_data
from tensorflow.keras.datasets.imdb import get_word_index
