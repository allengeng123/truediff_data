"""Utilities for ImageNet data preprocessing & prediction decoding."""
from tensorflow.keras.applications.imagenet_utils import decode_predictions
from tensorflow.keras.applications.imagenet_utils import preprocess_input
