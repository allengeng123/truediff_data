"""Built-in loss functions."""
from tensorflow.keras.losses import *
