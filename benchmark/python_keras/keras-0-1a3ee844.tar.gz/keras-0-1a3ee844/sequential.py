"""Sequential model class."""
from tensorflow.keras import Sequential
