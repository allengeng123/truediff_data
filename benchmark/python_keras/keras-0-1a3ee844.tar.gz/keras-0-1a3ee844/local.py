"""Locally-connected layers."""

from tensorflow.keras.layers import LocallyConnected1D
from tensorflow.keras.layers import LocallyConnected2D
