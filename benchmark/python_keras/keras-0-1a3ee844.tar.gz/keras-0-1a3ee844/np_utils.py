"""Numpy-related utilities."""

from tensorflow.keras.utils import to_categorical
from tensorflow.keras.utils import normalize
